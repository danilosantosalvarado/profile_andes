/* $Id: markerloader_static.js,v 1.3 2009/02/11 19:30:22 bdragon Exp $ */

/**
 * @file
 * GMap Marker Loader
 * Static markers.
 * This is a simple marker loader to read markers from the map settings array.
 * Commonly used with macros.
 */

/*global Drupal */

// Add a gmap handler
Drupal.gmap.addHandler('gmap', function (elem) {
    var obj = this;
    var marker, i;
    if (obj.vars.markers) {
        // Inject markers as soon as the icon loader is ready.
        obj.bind('iconsready', function () {
            for (i = 0; i < obj.vars.markers.length; i++) {
                marker = obj.vars.markers[i];
                if (!marker.opts) {
                    marker.opts = {};
                }
                // Pass around the object, bindings can change it if necessary.
                obj.change('preparemarker', -1, marker);
                // And add it.
                if (marker && marker.marker == undefined) {
                  obj.change('addmarker', -1, marker);
                }
            }
            obj.change('markersready', -1);
        });
    }
});
;
;
/**
 * @file
 * GMap Markers
 * Gmaps Utility Library MarkerManager API version
 */

/*global Drupal, GMarker, MarkerManager */

// Replace to override marker creation
Drupal.gmap.factory.marker = function (opts) {
    return new google.maps.Marker(opts);
};

Drupal.gmap.addHandler('gmap', function (elem) {
    var obj = this;

    obj.bind('init', function () {

        // Set up the markermanager.
        obj.mm = new MarkerManager(obj.map, Drupal.settings.gmap_markermanager);

        google.maps.event.addListener(obj.mm, 'loaded', function () {

            for (var i in obj.vars.markers) {

                var marker = obj.vars.markers[i];

                var minzoom = Drupal.settings.gmap_markermanager.markerMinZoom;
                var maxzoom = Drupal.settings.gmap_markermanager.markerMaxZoom;
                if (marker.minzoom) {
                    minzoom = marker.minzoom;
                }
                if (marker.maxzoom) {
                    maxzoom = marker.maxzoom;
                }
                if (maxzoom > 0) {
                    obj.mm.addMarker(marker.marker, minzoom, maxzoom);
                }
                else {
                    obj.mm.addMarker(marker.marker, minzoom);
                }
                obj.mm.refresh();

            }

        });

    });

    obj.bind('delmarker', function (marker) {
        obj.mm.removeMarker(marker.marker);
    });

    obj.bind('clearmarkers', function () {
        obj.mm.clearMarkers();
    });
});
;
