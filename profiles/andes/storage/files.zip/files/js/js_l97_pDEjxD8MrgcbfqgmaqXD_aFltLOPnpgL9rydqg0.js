"use strict";
(function($, Drupal) {
	var size = $(window).height();
	$("html").css("margin-top", size*3);
	setTimeout(function(){$(".region-navigation").css("margin-top", size*3);},10)

	Drupal.behaviors.Script = {
		attach: function (context, settings) {
			// function galeria home
			setTimeout(function(){
				$("html, .region-navigation").css("margin-top", 0);
				// var $menuMegaMenu = ($('.region-navigation.mainmenu-behavior-processed').length > 0  ) ? $('.mainmenu-behavior-processed').outerHeight(true) : 0 ;
				// setTimeout(function(){
				// 	var $menu_admin = ($('#admin-menu').length > 0) ? $('#admin-menu').outerHeight(true) : 0 ;
				// 	var $height_menu = $menuMegaMenu + $menu_admin;
				// 	$('body > .container-fluid.main-container').css({'margin-top': ($height_menu)});
				// },10);
			}	,2000);
			jQuery(document).on("click", ".galeria-home", function() {
				var imageSrc = $(this).find("img").attr("src");
				jQuery(".modal-gallery-home").attr("src", imageSrc);
			});
			//called the function for bullet container arrows
			bulletsContainerArrows();

			//move the arrows to outside to wrapper
			/*
			* get function bulletsContainerArrows();
			* this function is the responsible to get into Sliders class [container-arrows]
			* and move the arrows to outside from wrapper
			*/
			function bulletsContainerArrows() {
				// get a class [container-arrows] into slider
				var container_arrows = $('.container-arrows').find('.slider-pricipal-node');
				//verified if exist the lasted class
				if(container_arrows.length > 0) {
					// This item is responsible to move to outside the arrow prev
					$('.container-arrows .slider-pricipal-node .swiper-button-prev').appendTo('.container-arrows .skin-default');
					// This item is responsible to move to outside the arrow next
					$('.container-arrows .slider-pricipal-node .swiper-button-next').appendTo('.container-arrows .skin-default');
				}
			}

			//called the function activeEquipo for items active into page team.
			activeEquipo();
			/*
			* get function activeEquipo();
			* this function is the responsible to add class [team-active]
			* for principal page team
			*/
			function activeEquipo(){
				//verified url
				var u = String( decodeURI(window.location.href));
				//find a item a with a  team name
				$('.view-componente-equipo-trabajo').find('a[href="'+u+'"]').addClass('team-active');
			}
			//get a function homeFeaturedMultimedia() used for arrows ubication
			homeFeaturedMultimedia();

			/*
			* get function homeFeaturedMultimedia();
			* this function is the responsible to move the arrows
			* for principal Slider page home multimedia slider
			*/
			function homeFeaturedMultimedia() {
				$('.view-display-id-componente_multimedia_noticia_destacada .swiper-button-next')
					.appendTo('.view-display-id-componente_multimedia_noticia_destacada .pagination-wrap')
					.wrap( "<div class='wrap-arrows'></div>" );
				$('.view-display-id-componente_multimedia_noticia_destacada .swiper-button-prev').appendTo('.wrap-arrows');
				$('.view-display-id-componente_multimedia_noticia_destacada .views-field-view-1').appendTo('.views_slideshow_main');
			}

			// function wrapper to image element
			$('img').each(function() {
				//adding wrapper [figure] to images
				$(this).wrap('<figure></figure>');
			});
			//get a page size
			var pageSize = $(window).width();

			if (pageSize > 992) {socialDesktop(); }else {socialMobile(); }

			/*
			* get function socialMobile();
			* this function is used for add class to social align horizontal items
			*/
			function socialMobile(){
				if($('.align-social-vertical').hasClass('social-botton')){$('.align-social-vertical').removeClass('social-botton'); }
				if($('.align-social-vertical').hasClass('social-fixed')){$('.align-social-vertical').removeClass('social-fixed'); }
				if($('.align-social-vertical').hasClass('social-initial')){$('.align-social-vertical').removeClass('social-initial'); }
				$(".content-desktop").css("margin-left", "inherit");
				$('.align-social-vertical').addClass('social-mobile');
			}
			/*
			* get function socialDesktop();
			* this function is used for add class to social align vertical items
			*/
			function socialDesktop() {
				if($('.align-social-vertical').hasClass('social-mobile')){$('.align-social-vertical').removeClass('social-mobile');	}
				$('.align-social-vertical').addClass('content-desktop');
				var margen =  $(".container-node").offset();
				if (margen != null) {
					margen = margen['left']-$(".content-desktop").width();
				}
				$(".content-desktop").css("margin-left", margen);
			}

			$(window).resize(function(event) {
				var a = $(window).width();
				if (a > 991) {socialDesktop(); }else {socialMobile(); }
			});
			// this scroll is used for added data Social widget
			$(window).scroll(function() {
				var pageSize = $(window).width();
				if (pageSize > 991) {socialScrollDesktop(); }else {socialScrollMobile(); }
			});

			/*
			* get function socialScrollDesktop();
			* this function is used for move the items from widget Social
			*/
			function socialScrollDesktop(){
				var validation = $('body').find('.align-social-vertical');
				if (validation.length > 0){
							var margen =  $(".container-node").offset();
							if (margen != null) {
								margen = margen['left']-$(".content-desktop").width();
							}

							var panel = $('.align-social-vertical').parents('.panels-bootstrap-region').attr('id');
							var	panelId = '#'.concat(panel);
							var $menu_admin = $('#admin-menu').outerHeight(true);
							var $menu_navigation = $('.region-navigation').outerHeight(true);

							$('.align-social-vertical').prependTo(panelId);
							if( panelId !== null ) {
								var altoRerdes = $('.align-social-vertical').outerHeight(true);
								var scrollVentana = $(document).scrollTop();
								var contenedorTop = $(panelId).offset().top-($menu_navigation+$menu_admin);
								var contenerdorHeight = $(panelId).height() + contenedorTop;
								var endVerticalScroll = contenerdorHeight - altoRerdes;

								if (scrollVentana <= contenedorTop) {
									// exist social-bottom class
									if($('.align-social-vertical').hasClass('social-botton')){
										$('.align-social-vertical').removeClass('social-botton');
									}
									// exist social-fixed class
									if($('.align-social-vertical').hasClass('social-fixed')){
										$('.align-social-vertical').removeClass('social-fixed');
									}
									//social-initial
									$('.align-social-vertical').removeAttr("style");
									$('.align-social-vertical').addClass('social-initial');

									$(".content-desktop").css("margin-left", margen);

								}
								else if (scrollVentana >= contenedorTop) {
									// exist social-initial class
									if($('.align-social-vertical').hasClass('social-initial')){
										$('.align-social-vertical').removeClass('social-initial');
									}
									// exist social-bottom class
									if($('.align-social-vertical').hasClass('social-botton')){
										$('.align-social-vertical').removeClass('social-botton');
									}
									//social-fixed
									$('.align-social-vertical').addClass('social-fixed');
									$(".social-fixed").css({top: ($menu_admin+$menu_navigation)});
									// $('.align-social-vertical').addClass('social-fixed');

									$(".content-desktop").css("margin-left", margen);


								}
								if(scrollVentana > (contenerdorHeight-altoRerdes)) {
									// exist social-fixed class
									if($('.align-social-vertical').hasClass('social-fixed')){
										$('.align-social-vertical').removeClass('social-fixed');
									}
									// exist social-initial class
									if($('.align-social-vertical').hasClass('social-initial')){
										$('.align-social-vertical').removeClass('social-initial');
									}
									$('.align-social-vertical').removeAttr("style");
									//social-botton
									$('.align-social-vertical').addClass('social-botton');

									$(".content-desktop").css("margin-left", margen);
								}
							}
				}
			}
			/*
			* get function socialScrollMobile();
			* this function is used for move the items from widget Social
			*/
			function socialScrollMobile(){
				var validation = $('body').find('.social-mobile');
				if (validation.length > 0){
					$(panelId).css("background-color","red");
					var altoRerdes = $('.align-social-vertical').outerHeight(true);
					var menu_admin = $('#admin-menu').outerHeight(true);
					var menu_admin_height = $('#admin-menu').height();
					var menu_navigation = $('.navbar-header').outerHeight(true);

					var	panelId = '#'.concat($('.align-social-vertical').parents('.panels-bootstrap-region').attr('id'));
					var heightContent = $(panelId).height()-(menu_navigation+menu_admin);
					var scrollWindow = $(window).scrollTop();
					console.log(menu_admin);
					console.log(menu_navigation);
					var total =(menu_admin+menu_navigation+heightContent+$(panelId).offset().top)-(altoRerdes+20);

					if (scrollWindow < ($(panelId).offset().top - menu_admin_height) || scrollWindow > total) {
						if($('.social-mobile').hasClass('social-mobile-fixed')){
							$(".content-desktop").css("margin-left", "inherit");
							$('.social-mobile').removeClass('social-mobile-fixed');
						}
					}else {
						$(".content-desktop").css("margin-left", "inherit");
						$('.social-mobile').addClass('social-mobile-fixed');
						$('.social-mobile-fixed').css({
							top: menu_admin_height+menu_navigation
						});
					}
				}
			}
			//verified if exist data color attrib
			var color = $('.sabor').attr('data-color');
			//if color exist
			if (color !== null) {
				//adding border top
				$('#views_slideshow_swiper_componente_anuncios-block_1').find('.anuncios-conten').addClass('border-top-'+color);
				$('.swiper-pagination').addClass('pagination-'+color);
				$('#widget_pager_bottom_componente_anuncios-block_1 , #widget_pager_bottom_componente_eventos-block_3_1').addClass('pager-'+color);
				$('.anuncios-enlace').addClass('pager-'+color);

			}
			/**
			 * [listEvents description]
			 * @type {[type]}
			 */
			function slice(array, start, end) {
				var length = array == null ? 0 : array.length;
				if (!length) {
					return [];
				}
				start = start == null ? 0 : start;
				end = end === undefined ? length : end;

				if (start < 0) {
					start = -start > length ? 0 : (length + start);
				}
				end = end > length ? length : end;
				if (end < 0) {
					end += length;
				}
				length = start > end ? 0 : ((end - start) >>> 0);
				start >>>= 0;

				var index = -1;
				var result = new Array(length);
				while (++index < length) {
					result[index] = array[index + start];
				}
				return result;
			}
			function chunk(array, size) {
				size = Math.max(size, 0);
				var length = array == null ? 0 : array.length;
				if (!length || size < 1) {
					return [];
				}
				var index = 0;
				var resIndex = 0;
				var result = new Array(Math.ceil(length / size));

				while (index < length) {
					result[resIndex++] = slice(array, index, (index += size));
				}
				return result;
			}

			var eventsData = {size: 0};

			function listEvents(){
				var list = $('.view-eventos-decanatura .masonry-item').get();
				if (list.length == 0) {
					setTimeout(function(){listEvents();}, 200);
					return true;
				}
				eventsData.size = list.length;
				var partialEvents = chunk(list, 6);

				partialEvents.map(function(ls, idx){
					var opt = ls.length;

					switch(opt){
						case 6:
							$(ls[0]).addClass('item-full');
							$(ls[1]).addClass('item-lg');
							$(ls[2]).addClass('item-sm');
							$(ls[3]).addClass('item-lg');
							$(ls[4]).addClass('item-sm');
							$(ls[5]).addClass('item-full');
						break;
						case 5:
							$(ls[0]).addClass('item-lg');
							$(ls[1]).addClass('item-sm');
							$(ls[2]).addClass('item-lg');
							$(ls[3]).addClass('item-sm');
							$(ls[4]).addClass('item-full');
						break;
						case 4:
							$(ls[0]).addClass('item-lg');
							$(ls[1]).addClass('item-sm');
							$(ls[2]).addClass('item-lg');
							$(ls[3]).addClass('item-sm');
						break;
						case 3:
							$(ls[0]).addClass('item-sm');
							$(ls[1]).addClass('item-sm');
							$(ls[2]).addClass('item-full');
						break;
						case 2:
							$(ls[0]).addClass('item-sm');
							$(ls[1]).addClass('item-sm');
						break;
						case 1:
							$(ls[0]).addClass('item-full');
						break;
					}
				});

				var ua = window.navigator.userAgent;

				if( ua.indexOf("MSIE ") > 0 || ua.indexOf("rv:") > 0 ){
					ieSupport(partialEvents);
				}

				if( 'objectFit' in document.documentElement.style === false ){
					$('.imge-conten, .iframe-conten').addClass('object-fit');
					$('.imge-conten, .iframe-conten').each(function(idx, el){
						var srcImg = $(el).find('img').prop('src');
						$(el).css({'background-image': 'url(' + srcImg + ')'});
					});
				}

			}

			function onEventsLoad(){
				var newSizeEvents = $('.view-eventos-decanatura .masonry-item').length;
				if( newSizeEvents != eventsData.size ){
					listEvents();
					eventsLoad();
				}else{
					setTimeout(function(){onEventsLoad();}, 200);
				}
			}

			function eventsLoad() {
				var btnLoadMore = $('.view-eventos-decanatura .pager.pager-load-more a').get(0);
				if ( !btnLoadMore ) {
					setTimeout(function(){eventsLoad();}, 200);
					return false;
				}
				btnLoadMore.addEventListener('click', onEventsLoad, false);
			}

			function ieSupport(pList) {
				var partialEvents = pList;
				partialEvents.map(function(ls, idx) {
					var countRow = idx * 7;
					var opt = ls.length;

					$('.view-eventos-decanatura .view-content').attr("style", "margin: 10px !important");

					switch(opt){
						case 6:
							$(ls[0]).attr("style", "-ms-grid-column: 1; -ms-grid-row: " + (countRow + 1) + "; -ms-grid-column-span: 2;");
							$(ls[1]).attr("style", "-ms-grid-column: 1; -ms-grid-row: " + (countRow + 3) + "; -ms-grid-row-span: 2;");
							$(ls[2]).attr("style", "-ms-grid-column: 2; -ms-grid-row: " + (countRow + 3) + "; -ms-grid-row-span: 1;");
							$(ls[3]).attr("style", "-ms-grid-column: 2; -ms-grid-row: " + (countRow + 4) + "; -ms-grid-row-span: 2;");
							$(ls[4]).attr("style", "-ms-grid-column: 1; -ms-grid-row: " + (countRow + 5) + "; -ms-grid-row-span: 1;");
							$(ls[5]).attr("style", "-ms-grid-column: 1; -ms-grid-row: " + (countRow + 7) + "; -ms-grid-column-span: 2;");
						break;
						case 5:
							$(ls[0]).attr("style", "-ms-grid-column: 1; -ms-grid-row: " + (countRow + 1) + "; -ms-grid-row-span: 2;");
							$(ls[1]).attr("style", "-ms-grid-column: 2; -ms-grid-row: " + (countRow + 1) + "; -ms-grid-row-span: 1;");
							$(ls[2]).attr("style", "-ms-grid-column: 2; -ms-grid-row: " + (countRow + 3) + "; -ms-grid-row-span: 2;");
							$(ls[3]).attr("style", "-ms-grid-column: 1; -ms-grid-row: " + (countRow + 4) + "; -ms-grid-row-span: 1;");
							$(ls[4]).attr("style", "-ms-grid-column: 1; -ms-grid-row: " + (countRow + 5) + "; -ms-grid-column-span: 2;");
						break;
						case 4:
							$(ls[0]).attr("style", "-ms-grid-column: 1; -ms-grid-row: " + (countRow + 1) + "; -ms-grid-row-span: 2;");
							$(ls[1]).attr("style", "-ms-grid-column: 2; -ms-grid-row: " + (countRow + 1) + "; -ms-grid-row-span: 1;");
							$(ls[2]).attr("style", "-ms-grid-column: 2; -ms-grid-row: " + (countRow + 2) + "; -ms-grid-row-span: 2;");
							$(ls[3]).attr("style", "-ms-grid-column: 1; -ms-grid-row: " + (countRow + 3) + "; -ms-grid-row-span: 1;");
						break;
						case 3:
							$(ls[0]).attr("style", "-ms-grid-column: 1; -ms-grid-row: " + (countRow + 1) + "; -ms-grid-row-span: 1;");
							$(ls[1]).attr("style", "-ms-grid-column: 2; -ms-grid-row: " + (countRow + 1) + "; -ms-grid-row-span: 1;");
							$(ls[2]).attr("style", "-ms-grid-column: 1; -ms-grid-row: " + (countRow + 2) + "; -ms-grid-row-column: 2;");
						break;
						case 2:
							$(ls[0]).attr("style", "-ms-grid-column: 2; -ms-grid-row: " + (countRow + 1) + "; -ms-grid-row-span: 1;");
							$(ls[1]).attr("style", "-ms-grid-column: 1; -ms-grid-row: " + (countRow + 1) + "; -ms-grid-row-span: 1;");
						break;
						case 1:
							$(ls[0]).attr("style", "-ms-grid-column: 1; -ms-grid-row: " + (countRow + 1) + "; -ms-grid-column-span: 2;");
						break;
					}
				});
			}

			eventsLoad();
			listEvents();

			// galleria home support IE
			if( 'objectFit' in document.documentElement.style === false ){
				$('.wrapper-galeria-home .gh-item').addClass('object-fit');
				$('.wrapper-galeria-home .gh-item').each(function(idx, el){
					var srcImg = $(el).find('img').prop('src');
					console.log( $(el).find('img'));
					$(el).css({'background-image': 'url(' + srcImg + ')'});
				});
			}
			// menu expandible de equipo que desactiva el scroll del body

			$('#btn-list-equipo').click(function(){
				$('body').toggleClass('scroll-off');
			});

			setTimeout(function(){if($('.view-componente-acordeon 	.quicktabs-wrapper').length > 0){quickTabsSlide();} },1000);
			function quickTabsSlide(){
				var $parent = $('.quicktabs-wrapper').parents('.view');
				var $containerQuick = $parent.find('.quicktabs-wrapper').prepend('<a href="#" class="next-pagination">></a><a href="#" class="prev-pagination"><</a>');
				var $element = $containerQuick.find('ul');
				var $containerEl = $element.width();
				var $items = $element.find('li').length;
				var $itemsWidth = $element.find('li').outerWidth(true);
				var $numberOnclick = $items/parseInt($containerEl/$itemsWidth);
				var $counterData = 0;
				$containerQuick.find('.next-pagination').on('click',function(e){
					e.preventDefault();
					if($counterData >= 0 && $counterData < $numberOnclick){
						$counterData++;
						$element.animate({scrollLeft: ($counterData*parseInt($containerEl/$itemsWidth))*($itemsWidth)}, 800);
					}
					if($counterData >= $numberOnclick){
					$counterData--;
					}
				});
				$containerQuick.find('.prev-pagination').on('click',function(e){
					e.preventDefault();
					if($counterData > 0 && $counterData < $numberOnclick){
						$counterData--;
						$element.animate({scrollLeft: ($counterData*parseInt($containerEl/$itemsWidth))*($itemsWidth)}, 800);
					}
				});
			}
			//view-componente-enlaces-item
			setTimeout(function(){if($('.view-componente-enlaces-item').length > 0){componentEnlacesSlide();} },1000);
			function componentEnlacesSlide(){
				var $parent = $('.view-componente-enlaces-item').find('.view');
				var $containerItems = $('.view-componente-enlaces-item').find('.view-content').parent().prepend('<a href="#" class="next-pagination">></a><a href="#" class="prev-pagination"><</a>');
				var $element = $('.view-componente-enlaces-item').find('.view-content');
				var $containerEl = $element.width();
				var $items = $element.find('.views-row').length;
				var $itemsWidth = $element.find('.views-row').outerWidth(true);
				var $numberOnclick = $items/parseInt($containerEl/$itemsWidth);
				var $counterData = 0;
				$containerItems.find('.next-pagination').on('click',function(e){
					e.preventDefault();
					if($counterData >= 0 && $counterData < $numberOnclick){
						$counterData++;
						$element.animate({scrollLeft: ($counterData*parseInt($containerEl/$itemsWidth))*($itemsWidth)}, 800);
					}
					if($counterData >= $numberOnclick){
					$counterData--;
					}
				});
				$containerItems.find('.prev-pagination').on('click',function(e){
					e.preventDefault();
					if($counterData > 0 && $counterData < $numberOnclick){
						$counterData--;
						$element.animate({scrollLeft: ($counterData*parseInt($containerEl/$itemsWidth))*($itemsWidth)}, 800);
					}
				});
			}
			setTimeout(function(){if($('.view-componente-carrusel-multimedia.view-id-componente_carrusel_multimedia').length > 0){componentPagersSwyper();} },1000);
			function componentPagersSwyper(){
				var $parent = $('.view-componente-carrusel-multimedia.view-id-componente_carrusel_multimedia').find('.views-slideshow-controls-bottom');
				var $containerQuick = $parent.prepend('<a href="#" class="next-pagination">></a><a href="#" class="prev-pagination"><</a>');
				var $element = $('.view-componente-carrusel-multimedia.view-id-componente_carrusel_multimedia').find('.views_slideshow_pager_field');
				var $containerEl = $element.width();
				var $items = $element.find('.views-slideshow-pager-field-item').length;
				var $itemsWidth = $element.find('.views-slideshow-pager-field-item').outerWidth(true);
				var $numberOnclick = $items/parseInt($containerEl/$itemsWidth);
				var $counterData = 0;
				setTimeout(function(){
					var $element = $('.view-componente-carrusel-multimedia.view-id-componente_carrusel_multimedia').find('.views_slideshow_pager_field');
					var $containerEl = $element.width();
					var $items = $element.find('.views-slideshow-pager-field-item').length;
					var $itemsWidth = $element.find('.views-slideshow-pager-field-item').outerWidth(true);
					var $numberOnclick = $items/parseInt($containerEl/$itemsWidth);
					var $widthTotal = $items*$itemsWidth;
					if($widthTotal < $containerEl){
						$parent.find('.next-pagination, .prev-pagination').css('display', 'none');
					}
				},1000)


				$parent.find('.next-pagination').on('click',function(e){
					e.preventDefault();
					if(($counterData >= 0 && $counterData < $numberOnclick) || ($counterData >= 0 && numberOnclick  == 1 && $counterData <= $numberOnclick)){
						$counterData++;
						$element.animate({scrollLeft: ($counterData*parseInt($containerEl/$itemsWidth))*($itemsWidth)}, 800);
					}
					if($counterData > 0 && $counterData >= $numberOnclick && $numberOnclick != 1){
						$counterData--;
					}
				});
				$parent.find('.prev-pagination').on('click',function(e){
					e.preventDefault();
					if($counterData > 0 && $counterData < $numberOnclick){
						$counterData--;
						$element.animate({scrollLeft: ($counterData*parseInt($containerEl/$itemsWidth))*($itemsWidth)}, 800);
					}
				});
			};
		}
	}
})(jQuery, Drupal);

;
(function ($) {
  Drupal.behaviors.menuMain = {
    attach: function (context, settings) {
      var docWidth = $(document).width(),
      $dataId = 0,
      $levelNow = 0;
      /* ----| End Select clone of language change |----*/
      var $level1 = $('.tb-megamenu-menu-mega-menu .always-show ul.level-0 > li.level-1 > a'),
      $level1TopSoy = $('.tb-megamenu-menu-menu-top-soy .always-show ul.level-0 > li.level-1 > a'),
      $itemsNivel2 = $('.tb-megamenu-item.level-2.dropdown-submenu a.dropdown-toggle');
      $('.region-navigation', context).once('mainmenu-behavior', function () {
        /* wrapper para area segura  */
        $(".menu-soy-1").wrapAll("<div class='wrapper-menu-soy' />");
        $(".mega-menu-2").wrapAll("<div class='wrapper-mega-menu' />");
        $("#block-google-cse-google-cse.menu-buscar").wrapAll("<div class='wrapper-buscar-menu' />");
        $(".wrapper-menu-soy .menu-soy-1").wrapAll("<div class='container' />");
        $(".wrapper-mega-menu .mega-menu-2").wrapAll("<div class='container' />");


       /* modified data for language*/
        var currentlang = jQuery('html').attr('lang');
        var $search = (currentlang == 'es')  ? 'Buscar': (currentlang == 'en') ? 'Search': "";
        $('#google-cse-results-searchbox-form input').attr('placeholder', Drupal.t($search));
        $('#google-cse-results-searchbox-form').keypress(function(e) {
          //e.preventDefault();
          if(e.which == 13) {
            $('#google-cse-results-searchbox-form #edit-query').val();
            window.location = Drupal.settings.basePath+Drupal.settings.pathPrefix + "search/google/"+$('#google-cse-results-searchbox-form #edit-query').val();
          }
        });
        $('#google-cse-results-searchbox-form button:submit').on('click',function(e) {
          e.preventDefault();
          $('#google-cse-results-searchbox-form #edit-query').val();
          window.location = Drupal.settings.basePath+Drupal.settings.pathPrefix + "search/google/"+$('#google-cse-results-searchbox-form #edit-query').val();
        });
        /*End data language*/
        initDesktopMenu();
        getEventsClickDesktop();
        initMobileMenu();
        getEventsClickMobile();
        resizeGoToInstitucional();
        if(docWidth > 992){
          clearItemsfromMobile();
        }
        $('.container-language').click(function(e) {
          e.stopPropagation();
          if($('.select-options').hasClass('active')){
            $('.select-options').removeClass('active');
          }else{
            $('.select-options').addClass('active');
          }
        });
        $(document).click(function() {
          $('.select-options').removeClass('active');
        });

        /*Function resizeGoToInstitucional() */
        function resizeGoToInstitucional(){
          if($('.tb-megamenu-menu-menu-top-soy .level-0 li.level-1').length && ($(window).width() > 992 && $(window).width()< 1200)){
            $('.wrapper-menu-soy .container section').last().addClass('hidden');
          }else{
            $('.wrapper-menu-soy .container section').last().removeClass('hidden');
          }
        }
        /*End Function resizeGoToInstitucional() */

        /*init Resize*/
        $(window).resize(function(event) {
          if ($(window).width() > 992) {
            //initDesktopMenu();
            clearItemsfromMobile();
            //$('.wrapper-buscar-menu').hide();
          }
          else{
            $('.wrapper-buscar-menu').show();
            //clearItemsfromMobile();
            initMobileMenu();
          }
          resizeGoToInstitucional();
        });
        /* INIT Functions used for Desktop */
        function clearItemsfromMobile(){
          $(".container-language").show();
          if($('.container-select-language').length> 0)
            $('.container-select-language').html('');

          if($('.container-select-top-soy').length> 0)
            $('.container-select-top-soy').html('');

          if($('.container-destacados').length> 0)
            $('.container-destacados').html('');

          if($('.container-select-language').length> 0)
            $('.container-select-language').html('');

            if($('.menu-container-data').length> 0)
            $('.menu-container-data').remove();

            $('.navbar-collapse.collapse').removeAttr( 'style' );
            $('.wrapper-buscar-menu').removeAttr( 'style' );
        }
        function initDesktopMenu(){
          var menu = $('.navbar-header');
          menu.addClass(Drupal.settings.udla_blocks_alter.background_color_change);

          var $menuMegaMenu = ($('.region-navigation.mainmenu-behavior-processed').length > 0  ) ? $('.mainmenu-behavior-processed').outerHeight(true) : 0 ;
          var $searchData = ($('.wrapper-buscar-menu').length > 0) ? $('.wrapper-buscar-menu').outerHeight(true) : 0;
          if($(window).width() > 992){
            console.log("si carga la funcion" );
            setTimeout(function(){
              var $height_menu_desktop = $('.navbar-collapse .region-navigation .wrapper-menu-soy').outerHeight(true) + $('.navbar-collapse .region-navigation .wrapper-mega-menu').outerHeight(true);
              var $menu_admin = $('#admin-menu').length > 0;
              var $heigth_menu_admin = $('#admin-menu').outerHeight(true);
              console.log("menu: "+ $height_menu_desktop + " admin: "+ $heigth_menu_admin );
              if($menu_admin === true) {
                var $suma = $height_menu_desktop + $heigth_menu_admin;
                console.log("si hay mmenu admin:" + $suma);
                console.log("menu: "+ $height_menu_desktop + " admin: "+ $heigth_menu_admin );
                $('body > div.container-fluid.main-container').css({'margin-top': $height_menu_desktop + $heigth_menu_admin - 2});
              }else {
                $('body > div.container-fluid.main-container').css({'margin-top': $height_menu_desktop - 1});
              }
            },1290);
          }

          $(".wrapper-buscar-menu #block-google-cse-google-cse.menu-buscar").wrapAll("<div class='container' />");
          cloneSelect();

          $('.container-menu-image').parents('.tb-megamenu-column').addClass('content-img').siblings('.tb-megamenu-column').addClass('content-nivel-1');
          childrenEvent(".tb-megamenu-column .dropdown-toggle", "desktop");
          colorChange();
        }

        function getEventsClickDesktop(){
          if (!$('.mega-menu-2').hasClass('barra-buscar')) {
            $('.wrapper-mega-menu .nav-collapse').parent().append('<div class="barra-buscar mega-menu-2"><span>Cerrar</span></div>');
            $('.wrapper-buscar-menu').hide();
            $(".barra-buscar").click(function () {
              $(this).toggleClass('icon-close');
              $('.wrapper-buscar-menu').toggleClass('active');
              $('#block-google-cse-google-cse').toggleClass("buscador-open");
              if(jQuery('.buscador-open').length > 0){
                $('.wrapper-buscar-menu').slideDown('slow');
              }else{
                $('.wrapper-buscar-menu').slideUp('slow');
              }
            });
          }
          $level1.hover(
            function () {
              $dataId = $(this).parent().attr('data-id');
              // $('body').addClass('dark-layer');
              $('.dropdown-toggle').removeClass('text-hover');
              $('.menu-container-data active').remove();
              $('.menu-container-data').remove();
              $("div.active-nivel-1").removeClass('active-nivel-1');

            },
            function () {
              $(this).addClass('text-hover');
              if ($level1.find('>.nav-child')){
                $('body').removeClass('dark-layer');
              }
            }
          );
        }
        function cloneSelect(){
          if($('.container-language').length == 0){
            var $select = $('.lang_dropdown_form select');
            $select.parent('.form-item').append('<div class="container-language"></div><ul class="select-options"></ul>');
            $select.children().each(function(index, value){
              if($(this).attr('selected') != undefined){
                $('.container-language').html('<div>'+$(this).text().substring(0, 3)+'</div>');
              }else{
                $('.select-options').html('<li id="'+$(this).val()+'"><a href="#">'+$(this).text()+'</a></li>');
                $('.select-options li').click(function(e) {
                  jQuery(".lang_dropdown_form select").val($(this).attr('id')).trigger('change');
                });
              }
            })
          }
        }
        function colorChange(){
          /* Scroll menu cambio de color */
          $(window).scroll(function (event) {
            if($(window).width() > 992){
              let scroll = $(window).scrollTop(),
                  menu = $('.wrapper-mega-menu');
              if ( Drupal.settings.udla_blocks_alter !== undefined) {
                Drupal.settings.udla_blocks_alter.background_color = (Drupal.settings.udla_blocks_alter.background_color !== undefined) ? Drupal.settings.udla_blocks_alter.background_color : "";
                Drupal.settings.udla_blocks_alter.background_color_change = (Drupal.settings.udla_blocks_alter.background_color_change !== undefined )? Drupal.settings.udla_blocks_alter.background_color_change : "";
                Drupal.settings.udla_blocks_alter.text_color = (Drupal.settings.udla_blocks_alter.text_color !== undefined )? Drupal.settings.udla_blocks_alter.text_color : "";
                if(Drupal.settings.udla_blocks_alter.text_color != ""){
                  $('.view-logos-header p svg path').css('fill', Drupal.settings.udla_blocks_alter.color_svg);
                  $('.view-logos-header .views-row-last').css('border-left-color', Drupal.settings.udla_blocks_alter.color_svg);
                }
                if($(window).width() < 992){

                }
                else if (scroll > 10) {
                  menu.removeClass(Drupal.settings.udla_blocks_alter.background_color);
                  menu.addClass(Drupal.settings.udla_blocks_alter.background_color_change);
                  $(".barra-buscar").removeClass('cerrar');
                }
                else {
                  menu.removeClass(Drupal.settings.udla_blocks_alter.background_color_change);
                  menu.addClass(Drupal.settings.udla_blocks_alter.background_color);
                }
              }
            }
          });
        }
        /*END Functions used for Desktop */
        /* INIT Functions used for Mobile */
        function initMobileMenu(){
          //$(".container-language").hide();
          // $(".select-options").hide();

          $('.wrapper-mega-menu').removeClass(Drupal.settings.udla_blocks_alter.background_color_change);
          $('.navbar-toggle').attr('data-target', '#navbar-collapse, .nav-collapse');
          $('.menuIstance-processed').css('display','none');
          $('.container-menu-image').parents('.tb-megamenu-column').addClass('content-img').siblings('.tb-megamenu-column').addClass('content-nivel-1');

          var contentLength = $('.region-navigation .wrapper-mega-menu .view-id-logos_header .view-content div.views-row').length;

          if(contentLength == 1){
            if($('.wrapper-header-color').length == 0)
              $('.navbar-header button').wrapAll("<div class='wrapper-header-color' />");

            if($('.wrapper-header-color').html() == ""){
              var content = $('.region-navigation .wrapper-mega-menu .view-id-logos_header .view-content .views-row .field-content').html();
              $('.wrapper-header-color').prepend(content);
            }
          }else if(contentLength == 2){
            if($('.wrapper-header-color').length == 0)
              $('.navbar-header button').wrapAll("<div class='wrapper-header-color' />");

            if($('.wrapper-header-color').children().length == 1){
              var content = $('.region-navigation .wrapper-mega-menu .view-id-logos_header .view-content .field-content').first().html();
              $('.wrapper-header-color').prepend(content);
            }

            if($('.wrapper-header-up').length == 0)
              $('.navbar-header').prepend("<div class='wrapper-header-up' />");

            if($('.wrapper-header-up').html() == ""){
              // console.log("seeeee");
              var contentb = $('.region-navigation .wrapper-mega-menu .view-id-logos_header .view-content .views-row .field-content').last().html();
              // console.log('contentb');
              $('.wrapper-header-up').prepend(contentb);

            }
          }

          if($('.container-select-language').length == 0){
            var $secondSelect = $('#block-lang-dropdown-language');
            $('.wrapper-menu-soy').append('<div class="container-select-language"><span class="title-language">'+Drupal.t($secondSelect.find('.block-title').text())+'</span>'+$secondSelect.find('form').parent().html()+'</div>');
          }
          if($('.container-select-language').html() == ''){
            $('.navbar-header').addClass(Drupal.settings.udla_blocks_alter.background_color_change);
            $('.container-select-language').html('<span class="title-language">'+Drupal.t($secondSelect.find('.block-title').text())+'</span>'+$secondSelect.find('form').parent().html());
            $('.container-select-language select').on('change', function(){
              $(this).parents('form').submit();
            });
          }


          var $selectTopSoyItems =$('.wrapper-menu-soy li.level-1').not('.dropdown').not('.menu-destacado');
          if($('.container-select-top-soy').length == 0){
            $.each( $selectTopSoyItems, function( k, v ) {
              var $element = $(this).find('a');
              if(k == 0){
                $('.wrapper-menu-soy').append('<div class="container-select-top-soy"><span class="title-top-soy">'+Drupal.t($element.text())+'</span><select class="select-top-soy"><option value="">'+Drupal.t('Elegir')+'</option></select></div>');
              }else{
                $('.select-top-soy').append($('<option>', {value: $element.attr('href'), text: $element.text()}));
              }
            });
          }
          if($('.container-select-top-soy').html() == ''){
            $.each( $selectTopSoyItems, function( k, v ) {
              var  $element = $(this).find('a');
              if(k == 0){
                $('.container-select-top-soy').append('<span class="title-top-soy">'+Drupal.t($element.text())+'</span><select class="select-top-soy"><option value="">'+Drupal.t('Elegir')+'</option></select>');
              }else{
                $('.select-top-soy').append($('<option>', {value: $element.attr('href'), text: $element.text()}));
              }
            });
            $('.select-top-soy').on('change',function(){
               window.location.replace(Drupal.t(this.value));
            });
          }
          if($(window).width() < 992){
            var  $height_menu = $('.navbar-header').outerHeight();
            var  $height_menu_desktop = $('.navbar-collapse .region-navigation .wrapper-menu-soy').outerHeight() + $('.navbar-collapse .region-navigation .wrapper-mega-menu').outerHeight();
            $('#navbar-collapse').css("cssText", "margin-top: "+$height_menu+"px !important;");

            if($('.navbar-header .wrapper-header-color').length >0){
              $('body > div.container-fluid.main-container').css({'margin-top': $height_menu - 1 });
            }else{
              $('body > div.container-fluid.main-container').css({'margin-top': $height_menu_desktop });
            }
          }


          if($('.container-destacados').length == 0){
            var $selectDestacadosItems =$('.wrapper-menu-soy li.level-1.menu-destacado');
            $.each( $selectDestacadosItems, function( k, v ) {
              if(k == 0){
                $('.wrapper-menu-soy').append('<div class="container-destacados"><div class="menu-destacado">'+$(this).html()+'</div></div>');
              }else{
                $('.container-destacados').append('<div class="menu-destacado">'+$(this).html()+"</div>");
              }
            });
          }
          if($('.container-destacados').html() == ''){
            var  $selectDestacadosItems =$('.wrapper-menu-soy li.level-1.menu-destacado');
            $.each( $selectDestacadosItems, function( k, v ) {
              if(k == 0){
                $('.container-destacados').append('<div class="menu-destacado">'+$(this).html()+'</div>');
              }else{
                $('.container-destacados').append('<div class="menu-destacado">'+$(this).html()+"</div>");
              }
            });
          }

          // getEventsClickMobile();
        }
        function getEventsClickMobile(){
          $('.container-select-language select').on('change', function(){
            if($(window).width() < 992){
              $(this).parents('form').submit();
            }
          });
          $('.wrapper-header-color .navbar-toggle').on('click',function(){
            if($(window).width() < 992){
              $('body').toggleClass('active-menu');
              if($(this).attr('aria-expanded') == undefined || $(this).attr('aria-expanded') == 'false'){
                $(this).attr('aria-expanded',true);
              }else{
                $(this).attr('aria-expanded',false);
              }
            }
          });
          $('.select-top-soy').on('change',function(){
            if($(window).width() < 992){
              window.location.replace(Drupal.t(this.value));
            }
          });
          $level1.on('click',
            function (e) {
              e.preventDefault();
              if($(window).width() < 992){
                var  $dataId = $(this).parent().attr('data-id');
                $('body').addClass('dark-layer');
                $('.dropdown-toggle').removeClass('text-hover');
                $('.menu-container-data active').remove();
                $('.menu-container-data').remove();
                $("li.active-nivel-1").removeClass('active-nivel-1');
                var  $level = $(this).parent().attr('data-level');
                var  $levelNow = $level;
                var  $dataIdLocal = $(this).parent().attr('data-id');
                if($('.menu-container-data').length == 0){
                  $(this).parent().addClass('active-nivel-1');
                  var $nextMenu = $(".active-nivel-1").find(".tb-megamenu-column-inner").html();

                  $('.region-navigation').prepend("<div class='menu-container-data active level-"+$level+"'><div class='data-menu' style='display: none;'></div><div class='box-black' box-id='"+$dataIdLocal+"' box-level='"+$level+"'><p>" + $(this).text() + "</p></div><div class= 'container-items'>"+$nextMenu+"</div></div>");
                  if($nextMenu == undefined){
                    var $nextMenu = $(".active-nivel-1").find(".tb-megamenu-column-inner").html();
                  }
                  $('.container-items').html($nextMenu);
                  if( $('.data-menu .data-level-'+$level).length == 0){
                    $('.data-menu').append('<div class="data-level-'+$level+'"></div>');
                    $('.data-level-'+$level).text($(this).text());
                    $('.data-level-'+$level).attr('data-id', $dataIdLocal);
                  }else{
                    $('.data-level-'+$level).text($(this).text());
                    $('.data-level-'+$level).attr('data-id', $dataIdLocal);

                  }
                  animateLevelNext($level);
                  $('.menu-container-data.active .box-black').on('click', function(e){
                    e.preventDefault();
                    var $levelBox = $(this).attr('box-level');
                    var $IdBox = $(this).attr('box-id');
                    var $boxParent = $levelBox-1;
                    if($boxParent ==  0){
                      $('.menu-container-data.level-'+$boxParent).addClass('active');
                      animateLevelPrevious($boxParent,$levelBox);
                    }else{
                      $('.menu-container-data.level-'+$boxParent).addClass('active');
                      animateLevelPrevious($boxParent,$levelBox);
                    }
                  });
                  childrenEvent(".container-items .dropdown-toggle", 'mobile');
                }
              }
            }
          );
          $level1TopSoy.on('click',function(e) {
            if($(window).width() < 992) {
              var  $dataId = $(this).parent().attr('data-id');
              $('body').addClass('dark-layer');
              $('.dropdown-toggle').removeClass('text-hover');
              $('.menu-container-data active').remove();
              $('.menu-container-data').remove();
              $("li.active-nivel-1").removeClass('active-nivel-1');
              var $level = $(this).parent().attr('data-level');
              var $levelNow = $level;
              var $dataIdLocal = $(this).parent().attr('data-id');
              if($('.menu-container-data').length == 0){
                $(this).parent().addClass('active-nivel-1');
                var $nextMenu = $(".active-nivel-1").find('.content-nivel-1 .tb-megamenu-column-inner').html()
                $('.region-navigation').prepend("<div class='menu-container-data active level-"+$level+"'><div class='data-menu' style='display: none;'></div><div class='box-black' box-id='"+$dataIdLocal+"' box-level='"+$level+"'><p>" + $(this).text() + "</p></div><div class= 'container-items'>"+$nextMenu+"</div></div>");
                if($nextMenu == undefined){
                  var $nextMenu = $(".active-nivel-1").find(".tb-megamenu-column-inner").html();
                }
                $('.container-items').html($nextMenu);
                animateLevelNext($level);
                $('.menu-container-data.active .box-black').on('click', function(e){
                  e.preventDefault();
                  var $levelBox = $(this).attr('box-level');
                  var $IdBox = $(this).attr('box-id');
                  var $boxParent = $levelBox-1;
                  if($boxParent ==  0){
                    $('.menu-container-data.level-'+$boxParent).addClass('active');
                    animateLevelPrevious($boxParent,$levelBox);
                  }else{
                    $('.menu-container-data.level-'+$boxParent).addClass('active');
                    animateLevelPrevious($boxParent,$levelBox);
                  }
                });
                if( $('.data-menu .data-level-'+$level).length == 0){
                  $('.data-menu').append('<div class="data-level-'+$level+'"></div>');
                  $('.data-level-'+$level).text($(this).text());
                  $('.data-level-'+$level).attr('data-id', $dataIdLocal);
                }else{
                  $('.data-level-'+$level).text($(this).text());
                  $('.data-level-'+$level).attr('data-id', $dataIdLocal);

                }
                childrenEvent(".container-items .dropdown-toggle");
              }
            }
          });
        }
        function animateLevelNext($level){
          var $inner = $(".region-navigation .menu-container-data.active.level-"+$level);
            if ($inner.position().left == 0) {
              $inner.animate({left: "-100%"}, 'slide' );
            }else {
              $inner.animate({left:0},'slide');
            }
            $inner.one('webkitAnimationEnd oanimationend msAnimationEnd animationend',
            function(e) {
              $(".menu-container-data.level-"+$levelParent).removeClass('active');
            });
        }
        function animateLevelPrevious($level, $levelNow){
          var $inner = $(".region-navigation .menu-container-data.active.level-"+$levelNow);
          $inner.animate({left: "100%"}, "slide" );
          $inner.one('webkitAnimationEnd oanimationend msAnimationEnd animationend',
          function(e) {
            $(".menu-container-data.level-"+$levelNow).removeClass('active');
          });
        }
         /*END Functions used for Mobile */
        /*INIT Functions used for hibrid Desktop/Mobile */
        function childrenEvent( $class, $type){
          switch ($type) {
            case 'desktop':
              $($class).on("click", function (e) {
                e.preventDefault();
                var  $level = $(this).parent().attr('data-level');
                var  $levelNow = $level;
                var $dataIdLocal = $(this).parent().attr('data-id');
                if($('.menu-container-data').length == 0){
                  var $nextMenu = $("li[data-id='"+$dataId+"']").find("li[data-id='"+$dataIdLocal+"'] .tb-megamenu-column-inner").html();
                  $(this).parents('.tb-megamenu-column').addClass('active-nivel-1').before("<div class='menu-container-data'><div class='data-menu' style='display: none;'></div><div class='box-black' box-id='"+$dataIdLocal+"' box-level='"+$level+"'><p>" + $(this).text() + "</p></div><div class= 'container-items'>"+$nextMenu+"</div></div>");
                  $('.container-menu-image').toggleClass('active');
                  $(' .box-black').on('click', function(e){
                    e.preventDefault();
                    var $levelBox = $(this).attr('box-level');
                    var $IdBox = $(this).attr('box-id');
                    var $boxParent = $levelBox-1;
                    if($boxParent ==  1){
                      $('.menu-container-data').removeClass('active');
                      $("div.active-nivel-1").removeClass('active-nivel-1');
                      $('.container-items').html('');
                    }else if($boxParent> 1){
                      $boxLabel = $('.data-level-'+$boxParent).text();
                      $('.box-black p').text($boxLabel);
                      $('.box-black').attr('box-level',$boxParent);
                      $levelParent = $('.data-level-'+$boxParent).attr('data-id');
                      var $nextMenu = $(".active-nivel-1").find("li[data-id='"+$levelParent+"'] .tb-megamenu-column-inner").html();
                      $('.container-items').html($nextMenu);
                      childrenEvent(".container-items .dropdown-toggle", "desktop");
                    }
                  });
                }else{
                  $(this).parents('.tb-megamenu-column').addClass('active-nivel-1');
                  var $nextMenu = $(".active-nivel-1").find("li[data-id='"+$dataIdLocal+"'] .tb-megamenu-column-inner").html();
                  $('.container-items').html($nextMenu);
                  $('.box-black').attr('box-level',$level);
                  $('.box-black p').text($(this).text());
                  $('.data-level-'+$level).text($(this).text());
                  $('.data-level-'+$level).attr('data-id', $dataIdLocal);
                }
                if($nextMenu == undefined){
                  var $nextMenu = $(".active-nivel-1").find("li[data-id='"+$dataIdLocal+"'] .tb-megamenu-column-inner").html();
                }
                $('.container-items').html($nextMenu);
                if( $('.data-menu .data-level-'+$level).length == 0){
                  $('.data-menu').append('<div class="data-level-'+$level+'"></div>');
                  $('.data-level-'+$level).text($(this).text());
                  $('.data-level-'+$level).attr('data-id', $dataIdLocal);
                }else{
                  $('.data-level-'+$level).text($(this).text());
                  $('.data-level-'+$level).attr('data-id', $dataIdLocal);

                }
                childrenEvent(".container-items .dropdown-toggle", "desktop");
                $('.menu-container-data').addClass('active');
              });
              /*Init Alter dark layer */
              $('.tb-megamenu-nav.level-0 .level-1.dropdown').mouseover(function(e){
                $('body').addClass('dark-layer');
              });
              $('.tb-megamenu-nav.level-0 .level-1.dropdown').mouseout(function(e){
                $('body').removeClass('dark-layer');
              });
              /*End Alter dark layer */
              break;
              case 'mobile':
                $($class).on("click", function (e) {
                  e.preventDefault();
                  var $level = $(this).parent().attr('data-level');
                  var $levelParent = $level-1;
                  var $levelNow = $level;
                  var $dataIdLocal = $(this).parent().attr('data-id');
                  $(this).parents('.tb-megamenu-column').addClass('active-nivel-1');
                  var $nextMenu = $(".active-nivel-1").find("li[data-id='"+$dataIdLocal+"'] .tb-megamenu-column-inner").html();
                  if ($level > 0 &&$(".menu-container-data.level-"+$level).length == 0 || $(".menu-container-data.level-"+$level) == undefined){
                    $('.region-navigation').append("<div class='menu-container-data active level-"+$level+"'><div class='data-menu' style='display: none;'></div><div class='box-black' box-id='"+$dataIdLocal+"' box-level='"+$level+"'><p>" + $(this).text() + "</p></div><div class= 'container-items'>"+$nextMenu+"</div></div>");
                    $('.menu-container-data.active.level-'+$level+' .box-black').on('click', function(e){
                      e.preventDefault();
                      var $levelBox = $(this).attr('box-level');
                      var $IdBox = $(this).attr('box-id');
                      var $boxParent = $levelBox-1;
                      if($boxParent ==  0){
                        //$('.menu-container-data.level-'+$levelBox).removeClass('active');
                        $('.menu-container-data.level-'+$boxParent).addClass('active');
                        animateLevelPrevious($boxParent,$levelBox);
                      }else{
                        $('.menu-container-data.level-'+$boxParent).addClass('active');
                        animateLevelPrevious($boxParent,$levelBox);
                      }
                    });
                    animateLevelNext($level);

                  }else if($level > 0){
                    $('.menu-container-data level-'+$level).remove();
                    $('.region-navigation').append("<div class='menu-container-data active level-"+$level+"'><div class='data-menu' style='display: none;'></div><div class='box-black' box-id='"+$dataIdLocal+"' box-level='"+$level+"'><p>" + $(this).text() + "</p></div><div class= 'container-items'>"+$nextMenu+"</div></div>");
                    $('.menu-container-data.active.level-'+$level+' .box-black').on('click', function(e){
                      e.preventDefault();
                      var $levelBox = $(this).attr('box-level');
                      var $IdBox = $(this).attr('box-id');
                      var $boxParent = $levelBox-1;
                      if($boxParent ==  0){
                        //$('.menu-container-data.level-'+$levelBox).removeClass('active');
                        $('.menu-container-data.level-'+$boxParent).addClass('active');
                        animateLevelPrevious($boxParent,$levelBox);
                      }else{
                        $('.menu-container-data.level-'+$boxParent).addClass('active');
                        animateLevelPrevious($boxParent,$levelBox);
                      }
                    });
                    animateLevelNext($level);
                  }
                  childrenEvent(".container-items .dropdown-toggle", "mobile");
                  if( $('.data-menu .data-level-'+$level).length == 0){
                    $('.data-menu').append('<div class="data-level-'+$level+'"></div>');
                    $('.data-level-'+$level).text($(this).text());
                    $('.data-level-'+$level).attr('data-id', $dataIdLocal);
                  }else{
                    $('.data-level-'+$level).text($(this).text());
                    $('.data-level-'+$level).attr('data-id', $dataIdLocal);

                  }
                });
              break;
            default:
              break;
          }
        }
        /*END Functions used for hibrid desktop/mobile */
      });
    }
  }

}(jQuery));;
