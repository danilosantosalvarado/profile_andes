/* $Id: markerloader_static.js,v 1.3 2009/02/11 19:30:22 bdragon Exp $ */

/**
 * @file
 * GMap Marker Loader
 * Static markers.
 * This is a simple marker loader to read markers from the map settings array.
 * Commonly used with macros.
 */

/*global Drupal */

// Add a gmap handler
Drupal.gmap.addHandler('gmap', function (elem) {
    var obj = this;
    var marker, i;
    if (obj.vars.markers) {
        // Inject markers as soon as the icon loader is ready.
        obj.bind('iconsready', function () {
            for (i = 0; i < obj.vars.markers.length; i++) {
                marker = obj.vars.markers[i];
                if (!marker.opts) {
                    marker.opts = {};
                }
                // Pass around the object, bindings can change it if necessary.
                obj.change('preparemarker', -1, marker);
                // And add it.
                if (marker && marker.marker == undefined) {
                  obj.change('addmarker', -1, marker);
                }
            }
            obj.change('markersready', -1);
        });
    }
});
;
;
/**
 * @file
 * GMap Markers
 * Gmaps Utility Library MarkerClusterer API version
 */

/*global Drupal, GMarker, MarkerClusterer */

// Replace to override marker creation
Drupal.gmap.factory.marker = function (opts) {
    return new google.maps.Marker(opts);
};

Drupal.gmap.addHandler('gmap', function (elem) {
    var obj = this;

    obj.bind('init', function () {
        // Set up the markermanager.
        // Make sure the gridSize and maxZoom are intergers.
        if (Drupal.settings.gmap_markermanager.gridSize) {
            Drupal.settings.gmap_markermanager.gridSize = parseInt(Drupal.settings.gmap_markermanager.gridSize);
        }
        if (Drupal.settings.gmap_markermanager.maxZoom) {
            Drupal.settings.gmap_markermanager.maxZoom = parseInt(Drupal.settings.gmap_markermanager.maxZoom);
        }
        Drupal.settings.gmap_markermanager = jQuery.extend({}, {
            maxZoom: parseInt(Drupal.settings.gmap_markermanager.maxZoom),
            gridSize: parseInt(Drupal.settings.gmap_markermanager.gridSize)
        }, Drupal.settings.gmap_markermanager);
        obj.mc = new MarkerClusterer(obj.map, [], Drupal.settings.gmap_markermanager);
    });
    obj.bind('addmarker', function (marker) {
        // @@@ Would be really nice to have bulk adding support in gmap.
        obj.mc.addMarkers([marker.marker]);
    });

    obj.bind('delmarker', function (marker) {
        obj.mc.removeMarker(marker.marker);
    });

    obj.bind('clearmarkers', function () {
        obj.mc.clearMarkers();
    });
});
;
