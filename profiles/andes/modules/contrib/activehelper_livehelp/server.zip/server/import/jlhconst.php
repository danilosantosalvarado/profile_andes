<?php

define( "J_HOST", "http://localhost" );
define( "J_DOMAIN_SET_PATH", "E:\dev\htdocs\drupal/sites/all/modules/activehelper_livehelp/server/domains" );
define( "J_DIR_PATH", "/drupal/sites/all/modules/activehelper_livehelp" );
define( "J_CONF_PATH", "E:\dev\htdocs\drupal/sites/all/modules/activehelper_livehelp" );
define( "J_CONF_SSL", 0 );

?>