<?php
include_once('constants.php');

if (!isset($LANGUAGE_TYPE)) { define('LANGUAGE_TYPE', ''); }
if (!isset($CHARSET)) { define('CHARSET', ''); }

$livehelp_name = 'www.activehelper.com';
$livehelp_copyright_logo ='logo.jpg';
$online_install_logo = $install_directory . '/i18n/en/pictures/online_install_transparent.gif';
$site_name = 'www.activehelper.com';

$font_type = 'AkzidenzGrotesk';
$font_size = '12px';
$font_color = '#000000';
$font_link_color = '#333399';

$background_color = '#F9F9F9';

$departments = true;
$department = '';
$server = '';
$copyright_banners = '1';

?>

