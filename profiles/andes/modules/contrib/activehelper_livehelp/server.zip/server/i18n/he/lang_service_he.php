<?php

  $seconds = 'שניות';
  $session_expired = 'החיבור לתמיכה פעיל. החיבור ייתנתק בעוד';
  $password_incorrect = 'סיסמא לא נכונה';
  $login_account_incorrect = 'פרטי הכניסה לא נכונים';

  $unavailable_label = 'לא זמין';
  $initiated_default_label = 'בקשת תמיכה לא התחילה';
  $initiated_sending_label = ' נשלחת בקשת תמיכה אנושית...';
  $initiated_waiting_label = 'ממתינים לתשובה להתחלת תמיכה חיה...';
  $initiated_accepted_label = 'בקשת תמיכה חיה התקבלה';
  $initiated_declined_label = 'בקשת תמיכה חיה נדחתה';
  $initiated_chatting_label = 'כעת בשיחה עם תומך';
  $initiated_chatted_label = 'כבר נמצא בשיחה עם תומך';
  $initiated_pending_label = 'כרגע בהמתנה לתמיכה אנושית';
  $current_request_referrer_result = 'ביקור ישיר \ סימון';  

?>

