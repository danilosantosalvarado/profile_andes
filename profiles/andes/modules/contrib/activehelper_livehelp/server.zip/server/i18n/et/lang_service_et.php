<?php

  $seconds = 'Sekundit';
  $session_expired = 'La session de Livehelp esta activa. La sesion expirara en ';
  $session_expired = 'Livehelp seanss aktiivne. Sessioon lõppeb ';
  $password_incorrect = 'Vale parool';
  $login_account_incorrect = 'Vale kasutajatunnus või konto';

  $unavailable_label = 'Ei ole saadaval';
  $initiated_default_label = 'Live Help päring ei ole initsialiseeritud';
  $initiated_sending_label = 'Saadan Live Help päringu initsialiseerimiseks...';
  $initiated_waiting_label = 'Ootan initsialiseerimiseks Live Help vastus...';
  $initiated_accepted_label = 'Live Help initsialiseerimise päring on vastu võetud';
  $initiated_declined_label = 'Live Help initsialiseerimise päring on tagasi lükatud';
  $initiated_chatting_label = 'Praegu jututoas Operaatoriga';
  $initiated_chatted_label = 'Juba rääkis Operaatoriga';
  $initiated_pending_label = 'oodate Live Help vestlusringi';
  $current_request_referrer_result = 'Otsene külastus / Järjehoidjatesse';  

?>

