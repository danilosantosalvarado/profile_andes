<?php

  $seconds = 'Sekund';
  $session_expired = 'Platnost stránky vypršela ';
  $session_expired = 'Online chat je aktivní. Stránka vyprší za ';
  $password_incorrect = 'Neplatné heslo';
  $login_account_incorrect = 'Login nebo účet není platný';

  $unavailable_label = 'Nedostupné';
  $initiated_default_label = 'Požadavek na online chat nebyl inicializován';
  $initiated_sending_label = 'Odesílání požadavku na zahájení chatu...';
  $initiated_waiting_label = 'Čekání na odpověď online podpory...';
  $initiated_accepted_label = 'Požadavek na inicializaci online chatu byl AKCEPTOVÁN';
  $initiated_declined_label = 'Požadavek na inicializaci online chatu byl ZAMÍTNUT';
  $initiated_chatting_label = 'Jste připojeni k operátorovi';
  $initiated_chatted_label = 'Již jste byli připojeni k operátorovi';
  $initiated_pending_label = 'Čekáte na online podporu';
  $current_request_referrer_result = 'Přímá Návštěva / Bookmark';

?>
