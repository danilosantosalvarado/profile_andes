<?php

  $seconds = 'Segundos';
  $session_expired = 'A sessão LiveHelp está ativa. A sessão irá expirar em ';
  $session_expired = 'A sessão LiveHelp está ativa. A sessão será expirada em ';
  $password_incorrect = 'Senha Inválida';
  $schedule_time_incorrect ='O acesso não é permitido neste momento';
  $login_account_incorrect = 'Login ou conta inválida';

  $unavailable_label = 'Indisponível';
  $initiated_default_label = 'O pedido não foi iniciado';
  $initiated_sending_label = 'Iniciado o pedido de envio...';
  $initiated_waiting_label = 'Iniciado a espera da resposta...';
  $initiated_accepted_label = 'O Pedido foi ACEITO';
  $initiated_declined_label = 'O Pedido NÃO FOI ACEITO';
  $initiated_chatting_label = 'Atualmente conversando com o operador';
  $initiated_chatted_label = 'Já conversou com um operador';
  $initiated_pending_label = 'Pendência Atual para o LiveHelp';
  $current_request_referrer_result = 'Visita Direta/Bookmark';  

?>

