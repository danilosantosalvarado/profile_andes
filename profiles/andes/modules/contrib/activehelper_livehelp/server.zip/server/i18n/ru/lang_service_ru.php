<?php

  $seconds = 'сек.';
  $session_expired = 'Сессия активна.Истечет через ';
  $password_incorrect = 'Неверный ';
  $login_account_incorrect = 'Неверный логин или профиль';

  $unavailable_label = 'Недоступно';
  $initiated_default_label = 'Запрос не инициализирован';
  $initiated_sending_label = 'Отправляется запрос...';
  $initiated_waiting_label = 'Ожидание ответа...';
  $initiated_accepted_label = 'Запрос был принят';
  $initiated_declined_label = 'Запрос был отклонен';
  $initiated_chatting_label = 'Идет чат';
  $initiated_chatted_label = 'Чат уже состоялся';
  $initiated_pending_label = 'Ожидает';
  $current_request_referrer_result = 'Прямой заход / Закладка';  

?>

