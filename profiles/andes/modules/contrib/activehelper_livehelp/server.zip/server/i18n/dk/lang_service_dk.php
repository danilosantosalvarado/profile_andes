<?php

  $seconds = 'Sekunder';
  $session_expired = ' Live Help sessionen er aktiv. Sessionen vil udløbe om ';
  $password_incorrect = 'Adgangskoden er ikke korrekt';
  $login_account_incorrect = 'Login eller konto er ikke korrekt';
  $schedule_time_incorrect ='Adgang er ikke tilladt på dette tidspunkt';
  $unavailable_label = 'Er ikke tilstede';
  $initiated_default_label = 'Live Help anmodning er ikke initieret';
  $initiated_sending_label = 'Sender initierende Live Help anmodning...';
  $initiated_waiting_label = 'Afventer initierende Live Help respons...';
  $initiated_accepted_label = 'Initierende Live Help anmodning blev ACCEPTERET';
  $initiated_declined_label = 'Initierende Live Help anmodning blev AFVIST';
  $initiated_chatting_label = 'Du chatter nu med operatøren';
  $initiated_chatted_label = 'Har allerede chattet med en operatør';
  $initiated_pending_label = 'Venter på Live Help';
  $current_request_referrer_result = 'Direkte besøg / Bookmark';  

?>

