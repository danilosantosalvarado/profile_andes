<?php

  $seconds = 'sek.';
  $session_expired = 'La session de Livehelp esta activa. La sesion expirara en ';
  $session_expired = 'Live Help sesija ir aktîva. Sesija tiks slçgta pçc ';
  $password_incorrect = 'Ievadîtâ parole nav pareiza';
  $login_account_incorrect = 'Lietotâjvârds un/vai konts nav pareizs';

  $unavailable_label = 'Nav pieejams';
  $initiated_default_label = 'Pieprasîjums nav apstiprinâts';
  $initiated_sending_label = 'Tiek sûtîts pieprasîjums...';
  $initiated_waiting_label = 'Gaida uz pieprasîjumu...';
  $initiated_accepted_label = 'Pieprasîjums tika APSTIPRINÂTS';
  $initiated_declined_label = 'Pieprasîjums tika NORAIDÎTS';
  $initiated_chatting_label = 'Paðlaik èato ar operatoru';
  $initiated_chatted_label = 'Jau iepriekð ir sazinâjies ar operatoru';
  $initiated_pending_label = 'Paðlaik gaida rindâ';
  $current_request_referrer_result = 'Direct Visit / Bookmark';  

?>

