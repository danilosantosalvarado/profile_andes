<?php

  $seconds = 'Secondes';
  $session_expired = 'La session de Livehelp est active. La session expirera dans ';
  $password_incorrect = 'Mot de passe incorrect';
  $schedule_time_incorrect ='Accès pas permis pour le moment';
  $login_account_incorrect = 'Identifiant ou compte incorrect';

  $unavailable_label = 'Non disponible';
  $initiated_default_label = 'La demande de session n\'a pu aboutir';
  $initiated_sending_label = 'Envoi de la demande d\'ouverture de session...';
  $initiated_waiting_label = 'Attend le retour de la demande d\'ouverture de session...';
  $initiated_accepted_label = 'La demande d\'ouverture de session a été ACCEPTÉE';
  $initiated_declined_label = 'La demande d\'ouverture de session a été REFUSÉE';
  $initiated_chatting_label = 'Actuellement en discussion avec un opérateur';
  $initiated_chatted_label = 'Déjà en discussion avec un opérateur';
  $initiated_pending_label = 'Actuellement en attente d\'ouverture de session';
  $current_request_referrer_result = 'Accès direct / Favoris';  

?>

