<?php

  $seconds = 'Sekunde';
  $session_expired = 'LiveHelp konekcija je aktivna. Konekcija će istjeći za ';
  $session_expired = 'LiveHelp konekcija je aktivna. Konekcija će istjeći za ';
  $password_incorrect = 'Neispravna šifra';
  $login_account_incorrect = 'Neipravna šifra ili korisničko ime';

  $unavailable_label = 'Nedostupan';
  $initiated_default_label = 'Live Help zahtjev nije iniciran';
  $initiated_sending_label = 'Slanje inicijalnog Live Help zahtjeva...';
  $initiated_waiting_label = 'Čekam na inicijalni Live Help odgovor...';
  $initiated_accepted_label = 'Započet Live Help zahtjev je PRIHVAĆEN';
  $initiated_declined_label = 'Započet Live Help zahtjev je ODBIJEN';
  $initiated_chatting_label = 'Trenutno komunicirate za operaterom';
  $initiated_chatted_label = 'Već ste komunicirali sa operatorom';
  $initiated_pending_label = 'Trenutno čekate za Live Help razgovor';
  $current_request_referrer_result = 'Izravna posjeta / Oznaka';  

?>

