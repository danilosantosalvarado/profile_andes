<?php

  $seconds = 'Секунди';
  $session_expired = 'Има активна сесия. Изтича след ';
  $password_incorrect = 'Грешна парола';
  $login_account_incorrect = 'Грешен акаунт';

  $unavailable_label = 'Не е налично';
  $initiated_default_label = 'Поканата не е изпратена';
  $initiated_sending_label = 'Изпращане на покана...';
  $initiated_waiting_label = 'Изчакване на отговор...';
  $initiated_accepted_label = 'Поканата беше приета';
  $initiated_declined_label = 'Поканата беше отхвърлена';
  $initiated_chatting_label = 'В момента води разговор с оператор';
  $initiated_chatted_label = 'Вече е говорил с оператор';
  $initiated_pending_label = 'Изчаква "Онлайн помощ"';
  $current_request_referrer_result = 'Директно посещение / Отбележи';  

?>

