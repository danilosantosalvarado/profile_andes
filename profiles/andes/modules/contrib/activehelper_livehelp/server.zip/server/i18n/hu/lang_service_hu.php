<?php

  $seconds = 'Másodperc';
  $session_expired = 'A Chat Ügyfélszolgálati kapcsolat aktív. Beszélgetésének ideje ekkor jár le:';
  $password_incorrect = 'Helytelenül megadott jelszó';
  $login_account_incorrect = 'Helytelenül megadott felhasználói név vagy jelszó';

  $unavailable_label = 'Nem elérhetõ';
  $initiated_default_label = 'Nem indult el a Chat Ügyfélszolgálati beszélgetés';
  $initiated_sending_label = 'Chat Ügyfélszolgálati beszélgetés kezdeményezése';
  $initiated_waiting_label = 'Várakozás ügyfélszolgálat válaszára';
  $initiated_accepted_label = 'Segítségkérés elfogadva';
  $initiated_declined_label = 'Segítségkérés megtagadva';
  $initiated_chatting_label = 'Jelenleg munkatársunkkal vált üzenetet';
  $initiated_chatted_label = 'Már beszélgetett egyik munkatársunkkal';
  $initiated_pending_label = 'Ügyfélszolgálati válaszra vár';
  $current_request_referrer_result = 'Közvetlen látogatás / Könyvjelzõ';  

?>

