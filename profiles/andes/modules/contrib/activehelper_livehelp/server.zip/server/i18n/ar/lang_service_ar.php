﻿<?php

  $seconds = 'ثواني';
  $session_expired = 'الإستعلام الحي فعال الآن. سيتم فصل الإستعلام الحي بعد ';
  $session_expired = 'الإستعلام الحي فعال الآن. سيتم فصل الإستعلام الحي بعد ';
  $password_incorrect = 'كلمة المرور خاطئة';
  $login_account_incorrect = 'الدخول أو الحساب خطأ';

  $unavailable_label = 'غير موجود';
  $initiated_default_label = 'لم يتم تفعيل طلب الإستعلام';
  $initiated_sending_label = 'إرسال تفعيل طلب الإستعلام الحي...';
  $initiated_waiting_label = 'بإنتظار تفعيل طلب الإستعلام الحي...';
  $initiated_accepted_label = 'تمت الموافقة على طلب الإستعلام الحي';
  $initiated_declined_label = 'تم رفض طلب الإستعلام الحي';
  $initiated_chatting_label = 'أنت الآن في محادثة مع أحد العالمين';
  $initiated_chatted_label = 'قام بالمحادثة مع أحد العالمين';
  $initiated_pending_label = 'طلب الإستعلام الحي في الانتظار';
  $current_request_referrer_result = 'زيارة مباشرة / من خلال حفظ الصفحة';  

?>

