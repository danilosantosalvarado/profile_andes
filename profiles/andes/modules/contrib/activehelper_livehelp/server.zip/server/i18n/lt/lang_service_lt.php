<?php

  $seconds = 'Sek.';
  $session_expired = 'Pagalbos gyvai sesija yra aktyvi. Sesija pasibaigs po ';
  $password_incorrect = 'Slaptažodis neteisingas';
  $login_account_incorrect = 'Prisijungimo vardas arba slaptažodis yra neteisingas';

  $unavailable_label = 'Nepasiekiama';
  $initiated_default_label = 'Pagalbos gyvai užklausa nebuvo inicijuota';
  $initiated_sending_label = 'Siunčiama pagalbos gyvai inicijavimo užklausa...';
  $initiated_waiting_label = 'Laukiama kol bus atsiliepta į pagalbos gyvai inicijavimą...';
  $initiated_accepted_label = 'Pagalbos gyvai inicijavimo užklausa buvo PRIIMTA';
  $initiated_declined_label = 'Pagalbos gyvai inicijavimo užklausa buvo ATMESTA';
  $initiated_chatting_label = 'Šiuo metu kalbama su operatoriumi';
  $initiated_chatted_label = 'Jau kalbėta su operatoriumi';
  $initiated_pending_label = 'Šiuo metu laukia pagalbos gyvai';
  $current_request_referrer_result = 'Tiesioginis apsilankymas / Prenumerata';  

?>

